package com.example.tempfinal;



import static android.app.ProgressDialog.show;

import android.content.Context;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import org.w3c.dom.Text;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getSupportActionBar(). setDefaultDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setLogo(R.mipmap.ic_launcher);
        getSupportActionBar().setDisplayUseLogoEnabled(true);

        final EditText etTemperature = (EditText) findViewById(R.id.etTempersature);

        final RadioButton radFToC= (RadioButton)  findViewById(R.id.radFToC);
        final RadioButton radCToF= (RadioButton) findViewById(R.id.radCToF);

        Button convert= (Button) findViewById(R.id.btnConvert);

        final TextView tvResult= (TextView) findViewById(R.id.tvResult);

        convert.setOnClickListener(new view.OnClickLister());
        {
            @Override
                    public void onClick (View v);
                {
                if (etTemperature.getText().toString().isEmpty()){
                    Toast.makeText(Context:MainActivity.this, text: "Temperature is required!", Toast.LENGTH_LONG).show();
                    return;
                }

                double temperatureEntered= Double.parseDouble(etTemperature.getText().toString());
                String result= "";
            DecimalFormat tenth= new DecimalFormat(pattern: "#.#");

            if (radFToC.isChecked()){
                double convertedTemperature= (temperatureEntered-32)*5/9;
                result = temperatureEntered +  "F" + "is" + tenth.format(convertedTemperature) + "in Celsius";
                tvResult.setText(result);
            }
            if (radCToF.isChecked()){
                double convertedTemperature= (temperatureEntered*9/5)+32;
                result= temperatureEntered + "C" + "is" + tenth.format(convertedTemperature) + "in Fahrenheit";
                tvResult.setText(result);
            }
        }
        }
    }



}


